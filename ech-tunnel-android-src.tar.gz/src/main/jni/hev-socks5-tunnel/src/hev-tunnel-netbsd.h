/*
 ============================================================================
 Name        : hev-tunnel-netbsd.h
 Author      : hev <r@hev.cc>
 Copyright   : Copyright (c) 2025 hev
 Description : Tunnel on NetBSD
 ============================================================================
 */

#ifndef __HEV_TUNNEL_NETBSD_H__
#define __HEV_TUNNEL_NETBSD_H__

#endif /* __HEV_TUNNEL_NETBSD_H__ */
